﻿
namespace WFA220228
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.msVizsgak = new System.Windows.Forms.ToolStripMenuItem();
            this.msUjvizsga = new System.Windows.Forms.ToolStripMenuItem();
            this.dgvVizsga = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVizsga)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.msVizsgak,
            this.msUjvizsga});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1038, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // msVizsgak
            // 
            this.msVizsgak.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.msVizsgak.Name = "msVizsgak";
            this.msVizsgak.Size = new System.Drawing.Size(88, 29);
            this.msVizsgak.Text = "Vizsgák";
            this.msVizsgak.Click += new System.EventHandler(this.MsVizsgak_Click);
            // 
            // msUjvizsga
            // 
            this.msUjvizsga.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.msUjvizsga.Name = "msUjvizsga";
            this.msUjvizsga.Size = new System.Drawing.Size(119, 29);
            this.msUjvizsga.Text = "Új vizsgázó";
            this.msUjvizsga.Click += new System.EventHandler(this.MsUjvizsga_Click);
            // 
            // dgvVizsga
            // 
            this.dgvVizsga.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVizsga.Location = new System.Drawing.Point(39, 65);
            this.dgvVizsga.Name = "dgvVizsga";
            this.dgvVizsga.Size = new System.Drawing.Size(901, 424);
            this.dgvVizsga.TabIndex = 1;
            this.dgvVizsga.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvVizsga_CellContentClick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1038, 543);
            this.Controls.Add(this.dgvVizsga);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "Vizsgák";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVizsga)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem msVizsgak;
        private System.Windows.Forms.ToolStripMenuItem msUjvizsga;
        private System.Windows.Forms.DataGridView dgvVizsga;
    }
}

