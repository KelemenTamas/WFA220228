﻿
namespace WFA220228
{
    partial class frmKereso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbKeresnyelv = new System.Windows.Forms.ComboBox();
            this.dgvKeresnyelv = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeresnyelv)).BeginInit();
            this.SuspendLayout();
            // 
            // cbKeresnyelv
            // 
            this.cbKeresnyelv.FormattingEnabled = true;
            this.cbKeresnyelv.Location = new System.Drawing.Point(12, 34);
            this.cbKeresnyelv.Name = "cbKeresnyelv";
            this.cbKeresnyelv.Size = new System.Drawing.Size(607, 21);
            this.cbKeresnyelv.TabIndex = 0;
            // 
            // dgvKeresnyelv
            // 
            this.dgvKeresnyelv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKeresnyelv.Location = new System.Drawing.Point(12, 88);
            this.dgvKeresnyelv.Name = "dgvKeresnyelv";
            this.dgvKeresnyelv.Size = new System.Drawing.Size(607, 234);
            this.dgvKeresnyelv.TabIndex = 1;
            // 
            // frmKereso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 334);
            this.Controls.Add(this.dgvKeresnyelv);
            this.Controls.Add(this.cbKeresnyelv);
            this.Name = "frmKereso";
            this.Text = "Vizsga keresése";
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeresnyelv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbKeresnyelv;
        private System.Windows.Forms.DataGridView dgvKeresnyelv;
    }
}