﻿using System;

namespace WFA220228
{
    internal class SQLConnection : IDisposable
    {
    }
}