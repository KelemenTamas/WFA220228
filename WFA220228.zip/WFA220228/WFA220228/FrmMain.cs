﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WFA220228
{
    public partial class FrmMain : Form
    {
        public string ConnectionString {private get; set; }
        public FrmMain()
        {
            ConnectionString =
                "Server = (localdb)\\MSSQLLocalDB;" +
                "Database = nyelvvizsga;";
            InitializeComponent();
        } 
        private void FillDGV()
        {
            dgvVizsga.Rows.Clear();
            using (var conn = SqlConnection(ConnectionString))
            {
                var r = new SqlCommand(
                    "SELECT nylvek.id, jelentkezesek.nev, nyelvek.nyelv, vizsgak.szint " +
                    "FROM nyelvek, vizsgak, jelentkezesek" +
                    "WHERE nyelvek.id = vizsgak.nyelvid AND vizsgak.sorsz=jelentkezesek.vizsga;");
                conn.ExecuteReader();

                while (r.Read())
                {
                    dgvVizsga.Rows.Add(r[1], r[2], r[3]);
                }
            }
        }
        private void MsVizsgak_Click(object sender, EventArgs e)
        => new frmKereso().ShowDialog();

        private void MsUjvizsga_Click(object sender, EventArgs e)
        => new frmUjvizsgazo().ShowDialog();

        private void DgvVizsga_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void FrmMain_Load(object sender, EventArgs e)
        {
            FillDGV();
        }
    }
}
