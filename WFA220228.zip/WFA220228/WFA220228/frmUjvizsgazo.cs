﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFA220228
{
    public partial class frmUjvizsgazo : Form
    {
        public string ConnectionString { private get; set; }
        public frmUjvizsgazo()
        {
            ConnectionString =
            "Server = (localdb)\\MSSQLLocalDB;" +
            "Database = nyelvvizsga;";
            InitializeComponent();
        }

        private void BtnTorles(object sender, EventArgs e)
        {
            if (MessageBox.Show(
            
                text: "Biztos törli az adatot?",
                caption: "TÖRLÉS",
                buttons: MessageBoxButtons.YesNo,
                icon: MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Torles();
            } 
    }
        private void Torles()
        {
            TbID.Text = null;
            TbNev.Text = null;
            TbSzul.Text = null;
            TbTel.Text = null;
        }

        private void btnMentes_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TbID.Text))
            {
                if (MessageBox.Show(
                    text: "Biztos Menti az adatokat?",
                    caption: "MENTÉS",
                    buttons: MessageBoxButtons.YesNo,
                    icon: MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                }
            }
            else
            {

            }
        }
    }
    
    
}
