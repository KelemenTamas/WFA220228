﻿
namespace WFA220228
{
    partial class frmUjvizsgazo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TbID = new System.Windows.Forms.TextBox();
            this.TbNev = new System.Windows.Forms.TextBox();
            this.TbSzul = new System.Windows.Forms.TextBox();
            this.TbTel = new System.Windows.Forms.TextBox();
            this.btnTorles = new System.Windows.Forms.Button();
            this.btnMentes = new System.Windows.Forms.Button();
            this.btnUjvizsgazo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TbID
            // 
            this.TbID.Location = new System.Drawing.Point(33, 75);
            this.TbID.Name = "TbID";
            this.TbID.Size = new System.Drawing.Size(197, 20);
            this.TbID.TabIndex = 0;
            // 
            // TbNev
            // 
            this.TbNev.Location = new System.Drawing.Point(33, 127);
            this.TbNev.Name = "TbNev";
            this.TbNev.Size = new System.Drawing.Size(197, 20);
            this.TbNev.TabIndex = 1;
            // 
            // TbSzul
            // 
            this.TbSzul.Location = new System.Drawing.Point(33, 182);
            this.TbSzul.Name = "TbSzul";
            this.TbSzul.Size = new System.Drawing.Size(197, 20);
            this.TbSzul.TabIndex = 2;
            // 
            // TbTel
            // 
            this.TbTel.Location = new System.Drawing.Point(33, 231);
            this.TbTel.Name = "TbTel";
            this.TbTel.Size = new System.Drawing.Size(197, 20);
            this.TbTel.TabIndex = 3;
            // 
            // btnTorles
            // 
            this.btnTorles.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnTorles.Location = new System.Drawing.Point(315, 75);
            this.btnTorles.Name = "btnTorles";
            this.btnTorles.Size = new System.Drawing.Size(87, 72);
            this.btnTorles.TabIndex = 4;
            this.btnTorles.Text = "Törlés";
            this.btnTorles.UseVisualStyleBackColor = true;
            this.btnTorles.Click += new System.EventHandler(this.BtnTorles);
            // 
            // btnMentes
            // 
            this.btnMentes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnMentes.Location = new System.Drawing.Point(315, 153);
            this.btnMentes.Name = "btnMentes";
            this.btnMentes.Size = new System.Drawing.Size(87, 72);
            this.btnMentes.TabIndex = 5;
            this.btnMentes.Text = "Mentés";
            this.btnMentes.UseVisualStyleBackColor = true;
            this.btnMentes.Click += new System.EventHandler(this.btnMentes_Click);
            // 
            // btnUjvizsgazo
            // 
            this.btnUjvizsgazo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUjvizsgazo.Location = new System.Drawing.Point(302, 231);
            this.btnUjvizsgazo.Name = "btnUjvizsgazo";
            this.btnUjvizsgazo.Size = new System.Drawing.Size(114, 60);
            this.btnUjvizsgazo.TabIndex = 6;
            this.btnUjvizsgazo.Text = "Új vizsgázó";
            this.btnUjvizsgazo.UseVisualStyleBackColor = true;
            // 
            // frmUjvizsgazo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 335);
            this.Controls.Add(this.btnUjvizsgazo);
            this.Controls.Add(this.btnMentes);
            this.Controls.Add(this.btnTorles);
            this.Controls.Add(this.TbTel);
            this.Controls.Add(this.TbSzul);
            this.Controls.Add(this.TbNev);
            this.Controls.Add(this.TbID);
            this.Name = "frmUjvizsgazo";
            this.Text = "Új vizsgázó";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TbID;
        private System.Windows.Forms.TextBox TbNev;
        private System.Windows.Forms.TextBox TbSzul;
        private System.Windows.Forms.TextBox TbTel;
        private System.Windows.Forms.Button btnTorles;
        private System.Windows.Forms.Button btnMentes;
        private System.Windows.Forms.Button btnUjvizsgazo;
    }
}